package lambda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ListFilter {
	
	
	//@Test
	public void regular() {
		ArrayList<String> al = new ArrayList<String>();
		al.add("Abhi");
		al.add("Dan");
		al.add("Abby");
		al.add("Nick");
		al.add("alia");
		
		int count = 0;
		
		for(String a:al) {
			if(a.startsWith("A") || a.startsWith("a")) {
				System.out.println(a);
				count++;
			}
		}
		
		System.out.println("No of occurance : "+count);
		
	}
	
	//@Test
	
	public void streamFilter() {
		
		ArrayList<String> al = new ArrayList<String>();
		al.add("Abhi");
		al.add("Dan");
		al.add("Abby");
		al.add("Nick");
		al.add("alia");
		
		long c = al.stream().filter(s->s.startsWith("A") || s.startsWith("a")).count();
		System.out.println("Count : "+c);
		
		Optional<String> firstName = al.stream().filter(s->s.startsWith("A")).findFirst();
		System.out.println("FirstName : "+ firstName);
		
		Long d = Stream.of("Abhi","Dan","Abby","Nick","alia").filter(a->a.startsWith("A") || a.startsWith("a")).count();
		
		System.out.println("Count : "+d);
		
		Stream.of("Abhi","Dan","Abby","Nick","alia").filter(a->a.startsWith("A") || a.startsWith("a")).forEach(a->System.out.println(a));
		
		Stream.of("Abhi","Dan","Anny","Nick","Alia").filter(a->a.startsWith("A") || a.startsWith("a")).forEachOrdered(a->System.out.println(a));
		
		Stream.of("Abhi","Dan","Anny","Nick","Alia").filter(a->a.length()==3).forEach(a->System.out.println(a));
		
		Stream.of("Abhi","Dan","Abby","Nick","alia").filter(a->a.startsWith("A") || a.startsWith("a")).limit(2).forEach(a->System.out.println(a));
		
	
	}
	
	
	
	//@Test
	public void streamMap() {
		Stream.of("Abhijeet","Dan","Alia","Ranbir","Ayushman").filter(s->s.endsWith("a")).map(s->s.toUpperCase()).forEach(s->System.out.println(s));
	
		Stream.of("Abhijeet","Dan","Alia","Ranbir","Ayushman").map(s->s.toUpperCase()).forEach(s->System.out.println("Name: "+s));
		
		Stream.of("Abhijeet","Dan","Alia","Ranbir","Ayushman").filter(s->s.startsWith("A")).map(s->s.toUpperCase()).forEach(s->System.out.println(s));
	
		Stream.of("Azhar","Dan","Alia","Ranbir","Ayushman").filter(s->s.startsWith("A")).map(s->s.toUpperCase()).sorted().forEach(s->System.out.println("Sorted Name: "+s));
		
	}
	
	//@Test
	public void streamMatch() {
		ArrayList<String> name = new ArrayList<String>();
		name.add("Abhijeet");
		name.add("Dan");
		name.add("Alia");
		
		List <String> names =  Arrays.asList("Ranbir","Ayushman");	
		Stream<String> nameList= Stream.concat(name.stream(), names.stream());
		
		//nameList.forEach(s->System.out.println("Concat Element : "+s));
		
		boolean found = nameList.anyMatch(s->s.equalsIgnoreCase("Dan"));
		
		Assert.assertTrue(found);
	}
	
	@Test
	public void streamCollect() {
		List<Integer> li = Arrays.asList(10,12,10,8,15,7,9,8,21,15,10,13);
		//li.stream().distinct().sorted().forEach(s->System.out.println(s));
		
		List<Integer> newList = li.stream().distinct().sorted().collect(Collectors.toList());
		newList.stream().forEach(s->System.out.println(s));
		//System.out.println(newList.get(0));
		
		ListIterator<Integer> lt = newList.listIterator();
		while(lt.hasNext()) {
			System.out.println(lt.next());
		}
		
		
	}
	
	
}
