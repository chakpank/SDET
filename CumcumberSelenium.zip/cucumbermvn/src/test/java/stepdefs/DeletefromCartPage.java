package stepdefs;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import tests.DeletefromCartTest;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;


public class DeletefromCartPage {
	
		
	int expectedresult = 1;
	int cntBeforeDelete = 0;	
	
	WebDriverWait wait = new WebDriverWait(DeletefromCartTest.driver, 20);

	@Given("^user adds a \"(.*)\" type \"(.*)\"$")
	public void user_adds_a_product(String productName, String productType) throws Throwable {
		
		InputStream input = new FileInputStream("src/test/resources/Application.properties") ;
		Properties prop = new Properties();
		prop.load(input);		
		
		DeletefromCartTest.driver.get(prop.getProperty("app.URL"));
		DeletefromCartTest.driver.manage().window().maximize();	
		
		WebElement type = wait.until(ExpectedConditions.elementToBeClickable(By.linkText(productType)));
		type.click();
		
		WebElement product = wait.until(ExpectedConditions.elementToBeClickable(By.linkText(productName)));
		product.click();
		
		WebElement addToCart = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(".//a[contains(@class,'btn btn-success btn-lg')]")));
		addToCart.click();
		
		DeletefromCartTest.driver.switchTo().activeElement();
		Thread.sleep(1000);
		
		Alert alert  = DeletefromCartTest.driver.switchTo().alert();
		
		boolean result =  alert.getText().contains("Product added");
		Assert.assertTrue(result);
		
		alert.accept();		
		Thread.sleep(2000);

	}
	
	@When("^user navigate to cart$")
	public void user_navigate_to_cart() throws Throwable {	
		
		WebElement cart = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(".//a[contains(text(),'Cart')]")));
        cart.click();  
        Thread.sleep(2000);
	}
	
	
	@When("^user deletes the added \"(.*)\" from cart$")
	
	public void user_deletes_from_cart(String productname) throws Throwable {	
		
		ArrayList<WebElement> productList = (ArrayList<WebElement>) DeletefromCartTest.driver.findElements(By.xpath(".//table[contains(@class,'table table-bordered table-hover table-striped')]/tbody[contains(@id,'tbodyid')]/tr"));
        
		cntBeforeDelete = productList.size();
		
				
		for(WebElement el : productList) {
        	ArrayList<WebElement> cellList = (ArrayList<WebElement>) el.findElements(By.xpath("td"));
        	
        	for (WebElement cell : cellList) {
        		        		
        		if(cellList.get(1).getText().equals(productname)) {
        			
        			cellList.get(3).findElement(By.linkText("Delete")).click(); // Deleting the products from cart
        			
        		}
        	}        	
        	
        }
		
		Thread.sleep(2000);		       
	}
	

	@Then("^the product should be deleted from cart$")
	public void validate_the_delete_from_cart_is_successful() throws Throwable {	
		
		ArrayList<WebElement> updatedproductList = (ArrayList<WebElement>) DeletefromCartTest.driver.findElements(By.xpath(".//table[contains(@class,'table table-bordered table-hover table-striped')]/tbody[contains(@id,'tbodyid')]/tr"));
        
		int cntAfterDelete = updatedproductList.size();
		int actualresult =  cntBeforeDelete - cntAfterDelete;

		Assert.assertEquals(actualresult, expectedresult);		
		
		DeletefromCartTest.driver.close();	
		
	}


}
