package stepdefs;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import tests.AddtoCartTest;



public class AddtoCartPage {
	
	WebDriverWait wait = new WebDriverWait(AddtoCartTest.driver, 20);
	
	@Given("^user is in the Home Page of Product List$")
	public void user_in_home_page_product_list() throws Throwable {
		
		InputStream input = new FileInputStream("src/test/resources/Application.properties") ;
		Properties prop = new Properties();
		prop.load(input);		
		
		AddtoCartTest.driver.get(prop.getProperty("app.URL"));
		AddtoCartTest.driver.manage().window().maximize();	  
	}

	@When("^user navigate to \"(.*)\" Categories$")
	public void user_navigate_to_laptops_categories(String productType) throws Throwable {
		WebElement type = wait.until(ExpectedConditions.elementToBeClickable(By.linkText(productType)));
		type.click();		
	}

	@When("^user selects \"(.*)\" laptop$")
	public void user_select_sony_laptop(String productName) throws Throwable {	
		WebElement product = wait.until(ExpectedConditions.elementToBeClickable(By.linkText(productName)));
		product.click();
				
	}
	
	@When("^user add the product to cart$")
	public void user_add_product_to_cart() throws Throwable {	
		
		WebElement addToCart = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(".//a[contains(@class,'btn btn-success btn-lg')]")));
		addToCart.click();		
				
	}
		
	
	@Then("^user should see the \"(.*)\" message$")
	public void validate_the_product_added_to_cart_successfully(String confMessage) throws Throwable {	
		
		AddtoCartTest.driver.switchTo().activeElement();
		
		Thread.sleep(3000);
		
		Alert alert  = AddtoCartTest.driver.switchTo().alert();		
		boolean result =  alert.getText().contains(confMessage);
		Assert.assertTrue(result);		
		alert.accept();
		
		Thread.sleep(3000);
		
		AddtoCartTest.driver.close();		
				
	}

}
