package tests;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;

//Using tags option to turn on or turn off of execution from feature file

@CucumberOptions(
		features="src/test/resources/features",
		glue={"stepdefs"},
		format=
				{"pretty",
				"html:target/cucumber-reports/cucumber-pretty",
				"json:target/cucumber-reports/CucumberTestReport.json",
				"rerun:target/cucumber-reports/re-run.txt"},
		tags={"@Add_to_Cart_Test"}		
		)


public class AddtoCartTest {
	
	public static WebDriver driver;
	private TestNGCucumberRunner testRunner;
	
	@BeforeClass
	public void setUP()
	{
		System.setProperty("webdriver.chrome.driver", "D:/Software/chromedriver.exe");		 
        
		driver = new ChromeDriver();
		testRunner = new TestNGCucumberRunner(AddtoCartTest.class);
		
	}
	
	//Used enabled tag to turn on or turn off the execute of the test
	
	@Test(description="Add To Cart",dataProvider="features",enabled = true)
	public void addtocart(CucumberFeatureWrapper cFeature)
	{
		testRunner.runCucumber(cFeature.getCucumberFeature());
		
	}
	@DataProvider(name="features")
	public Object[][] getFeatures()
	{
		return testRunner.provideFeatures();
	}
	@AfterClass
	public void tearDown()
	{
		testRunner.finish();
	}


}
