
public class ProductFixture {
	
	public static Product door = new Product("door", 35);
	public static Product window = new Product("window", 15);
	public static Product floorPannel = new Product("floor", 50);

}
