
public class Chrome extends Base {

	@Override
	public void getBrowser() {
		System.out.println("Chrome Browser");
	}
}
