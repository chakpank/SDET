import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Shipment implements Iterable<Product> {

	public static final int LIGHT_VAN_MAX_WEIGHT = 20;	
	public final List<Product> products = new ArrayList<Product>();
	
	public List<Product> heavyVanProducts = new ArrayList<Product>();
	public  List<Product> lightVanProducts = new ArrayList<Product>();
	
	
	public void add(Product product) {		
		products.add(product);		
	}
	
	public void replace(Product oldProduct, Product newProduct) {
		
		int index = products.indexOf(oldProduct);
		
		if(index != -1) {
			products.set(index, newProduct);					
						
		}
		
	}
	
	public void prepare() {
		
		Collections.sort(products, Product.BY_WEIGHT);
		
		int splitPoint = findSplitPoint();
		
		lightVanProducts = products.subList(0, splitPoint);
		heavyVanProducts = products.subList(splitPoint, products.size());
	}
	
	public  int findSplitPoint() {
		for(int i=0; i<products.size(); i++) {
			final Product p = products.get(i);
			
			if(p.getWeight() > LIGHT_VAN_MAX_WEIGHT) {
				return i;
			}
		}
		return 0;
	}

	public List<Product> getHeavyVanProducts(){
		return heavyVanProducts;
	}
	
	public List<Product> getLightVanProducts(){
		return lightVanProducts;
	}
		
	public Iterator<Product> iterator(){
		return products.iterator();
	}
	
	public boolean contains(Product p, List<Product> products) {
		
		if(products.contains(p)) {
			return true;
		}else {
			return false;
		}
		
		
	}
	
public boolean contains(List<Product> pList, List<Product> products) {
		
		boolean status = false;
		
		for(Product p : pList) {
			if(products.contains(p)) {
				status = true;
			}else {
				status = false;
			}
		}
		
		return status;
		
		
	}
	
}


