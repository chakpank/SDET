import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.*;

import org.junit.jupiter.api.Test;

import junit.framework.Assert;



public class ShipmentTest {
	
	private Shipment shipment = new Shipment();
	private Product door = ProductFixture.door;
	private Product window = ProductFixture.window;
	private Product floor = ProductFixture.floorPannel;
	
	
	
	@Test
	public void shouldAddItems() {		
		
		shipment.add(door);
		shipment.add(window);		
		
		List<Product> pList = new ArrayList<Product>();
		pList.add(door);
		pList.add(window);
		
		Assert.assertTrue(shipment.contains(pList, shipment.products));
		
	}	
	
	@Test
	public void shouldNotReplaceItems() {
		shipment.add(door);
		shipment.replace(window, floor);
		
		Assert.assertFalse(shipment.contains(floor, shipment.products));
	}
	
	
	
	@SuppressWarnings("deprecation")
	@Test
	public void shouldReplaceItems() {
		
		shipment.add(door);
		shipment.add(window);
		
		shipment.replace(window, floor);
		
		List<Product> pList = new ArrayList<Product>();
		pList.add(door);
		pList.add(floor);
		
		Assert.assertTrue(shipment.contains(pList, shipment.products));
		

	}
	
	@Test
	public void shouldFigureVanType(){
		
		shipment.add(door);
		shipment.add(window);
		shipment.add(floor);		
		shipment.prepare();
		
		for(Product p : shipment.getLightVanProducts()) {
			System.out.println(p.toString());
		}
		
		for(Product p : shipment.getHeavyVanProducts()) {
			System.out.println(p.toString());
		}
	}
	

	

}
