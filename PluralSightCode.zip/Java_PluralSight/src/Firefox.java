
public class Firefox extends Base {

	@Override
	public void getBrowser() {
		System.out.println("Firefox Browser");
	}
}
