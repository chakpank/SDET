import java.util.Comparator;

public class Product {
	
	private final String name;
	private final int weight;
	
	public static final Comparator<Product> BY_WEIGHT = new Comparator<Product>() {
		
		public int compare(final Product p1, final Product p2) {
			return Integer.compare(p1.getWeight(), p2.getWeight()); 
		}
		
	};
	
	public Product(String name, int weight) {
		this.name = name;
		this.weight = weight;
	}
	
	public String getName() {return name;}
	
	public int getWeight() {return weight;}
	
	public static int BY_WEIGHT(Product p1, Product p2) {
		
		return (p1.getWeight() - p2.getWeight()) ;
		
	}
	
	
	@Override
	public String toString() {
		
		return "Product{ 'name=' "+name+", 'weight=' "+weight+"}";		
		
	}
	
	

}
