
public class Base {
	
	public void getBrowser() {
		System.out.println("Default Browser");
	}

}
