import java.util.Scanner;

public class Switch_Case {

	public static void main(String[] args) {
		
			
		Scanner sc = new Scanner(System.in);
		char choice = sc.next().charAt(0);	
		choice = Character.toLowerCase(choice);
		
		
		switch (choice) {
		
		case 'r':
			System.out.println("Red");
			break;
		case 'b':
			System.out.println("Black");
			break;
		case 'y':
			System.out.println("Yellow");
			break;
		default:
			System.out.println("Invalid Color");
		
		}
			
				

	}

}
