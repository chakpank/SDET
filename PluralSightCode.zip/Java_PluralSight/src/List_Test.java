import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class List_Test {

	public static void main(String[] args) {
		
	 Product p1 = new Product("Door",25);
	 Product p2 = new Product("Window",15);
	 
	 Collection<Product> coll = new ArrayList<Product>();
	 
	 coll.add(p1);
	 coll.add(p2);
	 
	 Iterator<Product> it = coll.iterator();
	 
	 while(it.hasNext()) {
		 Product p = it.next();
		 System.out.println(p.toString());
	 }
	
	
	}

}
