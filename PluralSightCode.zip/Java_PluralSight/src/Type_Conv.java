
public class Type_Conv {

	public static void main(String[] args) {
		
		int i = 5;
		String s = Integer.toString(i);
		s = s+5;
		i = Integer.parseInt(s);
		System.out.println(i*2);
				
		float f = i;
		
		System.out.println(f);
		
		i = (int)f;
		System.out.println(i);
		

	}

}
