
public class Client {
	
	public static void main(String [] args) {
		 //b = null;
		 Base b = new Base();
		b.getBrowser();
		
		b = new Chrome();
		b.getBrowser();
		
		b = new Firefox();
		b.getBrowser();
		
		b.getBrowser();
	}

}
