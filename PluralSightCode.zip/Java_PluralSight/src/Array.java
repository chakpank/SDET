import java.util.Arrays;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] arr = {1,2,3,4,5};
		int i =0;
		
		while (i<arr.length){
			System.out.println(arr[i]);
			try{
				int k = arr[i]/i;
				
			}catch(Exception e) {
				e.printStackTrace();
				
			}
			i+=1;
			
		}
	}

}
