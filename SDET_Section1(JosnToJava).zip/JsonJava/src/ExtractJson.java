import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ExtractJson {

	public static void main(String[] args) {
		ObjectMapper obj = new ObjectMapper();
		try {
			CustomerDetails c = obj.readValue(new File("C:\\Users\\panka\\eclipse-workspace\\JsonJava\\CustomerInfo_0.json"), CustomerDetails.class);
	        
			System.out.println(c.getCourseName());
			System.out.println(c.getAmount());
			System.out.println(c.getLocation());
			System.out.println(c.getPurchaseDate());
		
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
