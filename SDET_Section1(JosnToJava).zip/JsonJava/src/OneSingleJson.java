import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.fasterxml.jackson.databind.ObjectMapper;

public class OneSingleJson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			CustomerDetails c = new CustomerDetails();
			ObjectMapper objMap = new ObjectMapper();
			ArrayList<CustomerDetails> objList = new ArrayList<CustomerDetails>();
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Business", "root", "root");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from CustomerInfo where purchasedDate=CURDATE() and Location ='Asia';");
			
			while(rs.next()) {
				
				
				c.setCourseName(rs.getString(1));
				c.setPurchaseDate(rs.getString(2));
				c.setAmount(rs.getInt(3));
				c.setLocation(rs.getString(4));
				
				System.out.println(c.getCourseName());
				System.out.println(c.getPurchaseDate());
				System.out.println(c.getAmount());
				System.out.println(c.getLocation());
				
				objList.add(c);
				
				
			}
			
			for(int i = 0; i<objList.size();i++) {
				objMap.writeValue(new File("C:\\Users\\panka\\eclipse-workspace\\JsonJava\\CustomerInfo_"+i+".json"), objList.get(i));
				
			}
			
			
			//objMap.writeValue(new File("C:\\Users\\panka\\eclipse-workspace\\JsonJava\\CustomerInfo.json"), c);
			
			conn.close();
			
		} catch (ClassNotFoundException | SQLException | IOException e) {
			e.printStackTrace();
		}
	}

}
