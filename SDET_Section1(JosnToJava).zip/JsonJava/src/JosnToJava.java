import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.commons.text.StringEscapeUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

public class JosnToJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			
			ObjectMapper objMap = new ObjectMapper();
			ArrayList<CustomerDetails> objList = new ArrayList<CustomerDetails>();
			JSONArray jsonArr = new JSONArray();
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Business", "root", "root");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from CustomerInfo where location = 'Asia' and purchasedDate=curdate();");
			
			while(rs.next()) {
				
				CustomerDetails c = new CustomerDetails();
				
				c.setCourseName(rs.getString(1));
				c.setPurchaseDate(rs.getString(2));
				c.setAmount(rs.getInt(3));
				c.setLocation(rs.getString(4));
				
				objList.add(c);
								
			}
			
			for(int i = 0; i<objList.size();i++) {
				objMap.writeValue(new File("C:\\Users\\panka\\eclipse-workspace\\JsonJava\\CustomerInfo_"+i+".json"), objList.get(i));
				

				Gson g = new Gson();
				String jsonStr = g.toJson(objList.get(i)); 
				jsonArr.add(jsonStr);
				
			}
			
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("data", jsonArr);
			//System.out.println(jsonObj.toJSONString());
			
			String unescapeString = StringEscapeUtils.unescapeJava(jsonObj.toJSONString());
			//System.out.println(unescapeString);
			String String1 = unescapeString.replace("\"{", "{");
			String finalString = String1.replace("}\"", "}");
			System.out.println("Final String : "+finalString);
			
			@SuppressWarnings("resource")
			FileWriter file = new FileWriter("C:\\Users\\panka\\eclipse-workspace\\JsonJava\\CustomerInfo.json");
			file.write(finalString);
			file.flush();
			file.close();
			
			conn.close();
			
		} catch (ClassNotFoundException | SQLException | IOException e) {
			e.printStackTrace();
		}
	}

}
